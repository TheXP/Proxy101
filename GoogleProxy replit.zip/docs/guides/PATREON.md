
# How to access patreon links!
Welcome to this amazing guide :) 

## Step 1
**Become a patreon...**

*To follow this tutorial, you must be a patreon, duh.*


## Step 2
Find a supporter link in the patreon. Posts with links will have the `New links` tag, so just search for that.
Some links are expiramental and may not work as intended, but we will always tell you if it's expiramental. 
## Step 3

Use the password from the patreon post *Same post you got the link from, duh*
## Step 4

Enter the password and Start using Nebula
## Troubleshooting 

If the password is incorrect: 
- Make sure you entered the correct password
- Check the latest Patreon post to see if it changed *-- Only happens in emergencies, like password leaking*
- If none of those work, then and only then contact chloe@nebula.bio or GreenWorld#0001 on discord. 
## Authors

- [@green](https://www.git.holy.how/green)


## Appendix

This guide is 96% complete. If you are having any trouble accessing or using patreon/supporter only links, contact chloe@nebula.bio or GreenWorld#0001 on discord. 
