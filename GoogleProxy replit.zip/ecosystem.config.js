module.exports = {
    apps: [{
        name: "Google Site",
        script: "proxysocks node app.js"
    }]
}